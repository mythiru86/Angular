

let a:number = 20 ;  //a is of type number (explicitly) with value 20

let b;  //b is a variable that can hold 'any' thing. currently undefined

let c=30; //c is implicitly number (because of the value assigned to it)

let d:any=40; // d can hold anything, currently holding a number

a=40;

a='Hello'; //a can hold only number

b='Hello'; //b can hold anything

c='Hello'; //c must be a number

d='hello'; //d is allowed to be anything

