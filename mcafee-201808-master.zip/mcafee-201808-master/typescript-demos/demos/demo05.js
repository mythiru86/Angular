"use strict";
var a = 20; //a is of type number (explicitly) with value 20
var b; //b is a variable that can hold 'any' thing. currently undefined
var c = 30; //c is implicitly number (because of the value assigned to it)
var d = 40; // d can hold anything, currently holding a number
a = 40;
a = 'Hello'; //a can hold only number
b = 'Hello'; //b can hold anything
c = 'Hello'; //c must be a number
d = 'hello'; //d is allowed to be anything
