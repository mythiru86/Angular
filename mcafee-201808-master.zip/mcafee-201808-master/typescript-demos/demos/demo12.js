"use strict";
(function () {
    var people = [
        {
            name: 'Vivek',
            email: 'vivek@conceptarchitect.in',
            phone: '9036084835'
        },
        {
            name: 'Sanjay',
            email: 'sanjay@conceptarchitect.in'
        },
        {
            name: 'Shivanshi',
            email: 'shivanshi@conceptarchitect.in'
        },
    ];
})();
