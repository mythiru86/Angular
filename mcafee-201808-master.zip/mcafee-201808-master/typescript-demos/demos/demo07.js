"use strict";
var person = {
    name: 'Vivek',
    email: 'vivek@conceptarchitect.in'
};
console.log('person', person);
//person is an object of a type that contains name:string, email:string
person.phone = '90360 84835'; //this typehas no phone property
var person2 = {
    name: 'Vivek',
    email: 'vivek@conceptarchitect.in'
};
person2.phone = '90360 84835';
