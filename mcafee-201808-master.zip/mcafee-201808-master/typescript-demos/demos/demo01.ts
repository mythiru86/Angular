
function greet(name, prefix='Hello', suffix='Welcome to our Service'){
    console.log(`${prefix} ${name}, ${suffix}`);
}

greet('Vivek');

greet('Vivek','Hi','How Are you');



